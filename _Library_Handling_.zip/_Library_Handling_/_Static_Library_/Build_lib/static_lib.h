#ifndef foo_h__
#define foo_h__

extern void foo(void);
#endif //foo___