	


* Build_library Folder
	1. run all source(.c) to object(.o) file 
		>gcc -Wall -c my_lib.c -o my_lib.o
		>gcc -Wall -c static_lib.c -o static_lib.o	
	2. create library (.a) with all objected file were declared in header file(.h)
		>ar -r -s mylib.a static_lib.o my_lib.o
when build library, should creat only header file containing all function reference in that.



	gcc -Wall -c main.c -o main.o 
gcc -Wall -o test_Lib.exe D:\03_Progarm_C\_Library_Handling_\_Static_Library_\Project_demo\main.o D:\03_Progarm_C\_Library_Handling_\_Static_Library_\Build_library\mylib.a