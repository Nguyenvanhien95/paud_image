#include <stdio.h>
#include <stdlib.h>

#include <D:\03_Progarm_C\_Library_Handling_\_Static_Library_\Build_lib\static_lib.h>


int main()
{
	message();
	return 0;
}