#include <stdio.h>
#include "static_lib.h"
 
int message(void)
{
    puts("This is a shared library test...");
    foo();
    return 0;
}