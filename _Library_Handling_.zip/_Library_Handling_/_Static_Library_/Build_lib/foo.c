#include <stdio.h>

void foo(void)
{
	puts("Hello, I am a static library");
}
